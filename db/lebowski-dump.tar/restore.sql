--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.quotes DROP CONSTRAINT quotes_pkey;
ALTER TABLE ONLY public.lines DROP CONSTRAINT lines_pkey;
ALTER TABLE ONLY public.characters DROP CONSTRAINT characters_pkey;
ALTER TABLE ONLY public.actors DROP CONSTRAINT actors_pkey;
ALTER TABLE public.quotes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.characters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.actors ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.quotes_id_seq;
DROP TABLE public.quotes;
DROP SEQUENCE public.lines_id_seq;
DROP TABLE public.lines;
DROP SEQUENCE public.characters_id_seq;
DROP TABLE public.characters;
DROP SEQUENCE public.actors_id_seq;
DROP TABLE public.actors;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actors; Type: TABLE; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE TABLE actors (
    id integer NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    character_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.actors OWNER TO lebowski;

--
-- Name: actors_id_seq; Type: SEQUENCE; Schema: public; Owner: lebowski
--

CREATE SEQUENCE actors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.actors_id_seq OWNER TO lebowski;

--
-- Name: actors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lebowski
--

ALTER SEQUENCE actors_id_seq OWNED BY actors.id;


--
-- Name: characters; Type: TABLE; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE TABLE characters (
    id integer NOT NULL,
    name character varying(255),
    actor_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.characters OWNER TO lebowski;

--
-- Name: characters_id_seq; Type: SEQUENCE; Schema: public; Owner: lebowski
--

CREATE SEQUENCE characters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characters_id_seq OWNER TO lebowski;

--
-- Name: characters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lebowski
--

ALTER SEQUENCE characters_id_seq OWNED BY characters.id;


--
-- Name: lines; Type: TABLE; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE TABLE lines (
    id integer NOT NULL,
    text text,
    character_id integer,
    quote_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.lines OWNER TO lebowski;

--
-- Name: lines_id_seq; Type: SEQUENCE; Schema: public; Owner: lebowski
--

CREATE SEQUENCE lines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lines_id_seq OWNER TO lebowski;

--
-- Name: lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lebowski
--

ALTER SEQUENCE lines_id_seq OWNED BY lines.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE TABLE quotes (
    id integer NOT NULL,
    image character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.quotes OWNER TO lebowski;

--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: lebowski
--

CREATE SEQUENCE quotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quotes_id_seq OWNER TO lebowski;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lebowski
--

ALTER SEQUENCE quotes_id_seq OWNED BY quotes.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO lebowski;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lebowski
--

ALTER TABLE ONLY actors ALTER COLUMN id SET DEFAULT nextval('actors_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lebowski
--

ALTER TABLE ONLY characters ALTER COLUMN id SET DEFAULT nextval('characters_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lebowski
--

ALTER TABLE ONLY lines ALTER COLUMN id SET DEFAULT nextval('lines_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: lebowski
--

ALTER TABLE ONLY quotes ALTER COLUMN id SET DEFAULT nextval('quotes_id_seq'::regclass);


--
-- Data for Name: actors; Type: TABLE DATA; Schema: public; Owner: lebowski
--

COPY actors (id, first_name, last_name, character_id, created_at, updated_at) FROM stdin;
\.
COPY actors (id, first_name, last_name, character_id, created_at, updated_at) FROM '$$PATH$$/2221.dat';

--
-- Name: actors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lebowski
--

SELECT pg_catalog.setval('actors_id_seq', 1, false);


--
-- Data for Name: characters; Type: TABLE DATA; Schema: public; Owner: lebowski
--

COPY characters (id, name, actor_id, created_at, updated_at) FROM stdin;
\.
COPY characters (id, name, actor_id, created_at, updated_at) FROM '$$PATH$$/2223.dat';

--
-- Name: characters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lebowski
--

SELECT pg_catalog.setval('characters_id_seq', 64, true);


--
-- Data for Name: lines; Type: TABLE DATA; Schema: public; Owner: lebowski
--

COPY lines (id, text, character_id, quote_id, created_at, updated_at) FROM stdin;
\.
COPY lines (id, text, character_id, quote_id, created_at, updated_at) FROM '$$PATH$$/2225.dat';

--
-- Name: lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lebowski
--

SELECT pg_catalog.setval('lines_id_seq', 1, false);


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: lebowski
--

COPY quotes (id, image, created_at, updated_at) FROM stdin;
\.
COPY quotes (id, image, created_at, updated_at) FROM '$$PATH$$/2227.dat';

--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lebowski
--

SELECT pg_catalog.setval('quotes_id_seq', 147, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: lebowski
--

COPY schema_migrations (version) FROM stdin;
\.
COPY schema_migrations (version) FROM '$$PATH$$/2219.dat';

--
-- Name: actors_pkey; Type: CONSTRAINT; Schema: public; Owner: lebowski; Tablespace: 
--

ALTER TABLE ONLY actors
    ADD CONSTRAINT actors_pkey PRIMARY KEY (id);


--
-- Name: characters_pkey; Type: CONSTRAINT; Schema: public; Owner: lebowski; Tablespace: 
--

ALTER TABLE ONLY characters
    ADD CONSTRAINT characters_pkey PRIMARY KEY (id);


--
-- Name: lines_pkey; Type: CONSTRAINT; Schema: public; Owner: lebowski; Tablespace: 
--

ALTER TABLE ONLY lines
    ADD CONSTRAINT lines_pkey PRIMARY KEY (id);


--
-- Name: quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: lebowski; Tablespace: 
--

ALTER TABLE ONLY quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: lebowski; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

